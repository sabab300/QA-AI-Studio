"""
QA AI Studio
Upload Pipeline

Version: 3.1
"""

import re
from pathlib import Path

from Core.repository_manager import RepositoryManager
from Core.metadata_manager import MetadataManager
from Core.text_extractor import TextExtractor
from Core.knowledge_analyzer import KnowledgeAnalyzer
from Core.embedding_engine import EmbeddingEngine
from Core.vector_store import VectorStore
from Core.document_chunker import DocumentChunker
from Core.smart_upload import SmartUpload

def _id_part(value):
    """Sanitize one piece of a ChromaDB doc id: keep it stable and
    collision-safe by stripping anything that isn't alnum/dash/underscore."""

    return re.sub(r"[^A-Za-z0-9_-]+", "-", str(value)).strip("-") or "x"


class UploadPipeline:

    def __init__(self):

        self.repository = RepositoryManager()
        self.metadata = MetadataManager()
        self.extractor = TextExtractor()
        self.analyzer = KnowledgeAnalyzer()
        self.embedding = EmbeddingEngine()
        self.chunker = DocumentChunker()
        self.smart_uploader = SmartUpload()
        self.vector_store = VectorStore()

    # --------------------------------------------------
    # Upload File
    # --------------------------------------------------

    def upload_file(
        self,
        source_file,
        domain,
        module,
        knowledge_name,
        version="1.0",
        document_type="",
        reviewed_analysis=None,
        source_type="FILE",
        ):

        source_file = Path(source_file).resolve()

        file_info = self.repository.save_file(
            source_file=str(source_file),
            domain=domain,
            module=module,
            knowledge_name=knowledge_name,
            version=version,
            document_type=document_type
        )

        text = self.extractor.extract_text(
            file_info["repository_path"]
        )

        if not str(text or "").strip():
            # A non-empty binary can still contain no extractable knowledge.
            # Do not report success or leave a managed orphan in that case.
            try:
                Path(file_info["repository_path"]).unlink()
            except OSError:
                pass
            raise ValueError("The source contains no extractable text.")

        # Smart Upload has already run the real analyzer and allowed an
        # operator to review its result.  Re-analyzing here would waste work
        # and could silently overwrite reviewed Summary/Tags.
        try:
            analysis = dict(
                reviewed_analysis
                if reviewed_analysis is not None
                else self.analyzer.analyze(text)
            )
        except Exception:
            try:
                Path(file_info["repository_path"]).unlink()
            except OSError:
                pass
            raise

        def rollback_persisted_upload():
            try:
                self.metadata.delete(metadata_status)
            finally:
                try:
                    Path(file_info["repository_path"]).unlink()
                except OSError:
                    pass

        print("SUMMARY:", analysis.get("summary"))

        if file_info.get("document_type"):
            analysis["document_type"] = file_info["document_type"]

        try:
            metadata_status = self.metadata.save_knowledge_item(
                domain=domain,
                module=module,
                knowledge_name=knowledge_name,
                version=version,
                file_info=file_info,
                analysis=analysis,
                source_type=source_type,
            )
        except Exception:
            try:
                Path(file_info["repository_path"]).unlink()
            except OSError:
                pass
            raise

# PATCH — AI/Core/upload_pipeline.py
#
# Replace the chunk loop (lines ~79-122 — from "chunks = self.chunker.split(text)"
# through the end of the "for index, chunk in enumerate..." loop) with this.
#
# Before: N chunks -> N separate model.encode() calls -> N separate
#         ChromaDB add() calls.
# After:  N chunks -> 1 batched model.encode() call -> 1 batched
#         ChromaDB add() call. Same result, much fewer round trips.

        try:
            chunks = self.chunker.split(text)
        except Exception:
            rollback_persisted_upload()
            raise

        vectors_saved = 0

        if chunks:

            try:
                embeddings = self.embedding.generate_embeddings(chunks)
            except Exception:
                rollback_persisted_upload()
                raise

            if embeddings is None:

                embeddings = [None] * len(chunks)

            batch_items = []

            for index, chunk in enumerate(chunks, start=1):

                embedding = embeddings[index - 1]

                if embedding is None:

                    continue

                # BUGFIX: the chunk id used to be just
                # f"{file_info['sha256']}_{index}" — based only on file
                # CONTENT hash + chunk position, with no domain/module/
                # knowledge_name/version in it. Two versions of the same
                # knowledge item that happen to share identical file
                # content (e.g. a re-upload with no real changes) then
                # produced the SAME chunk id, so the second upload's
                # ChromaDB add() silently overwrote the first version's
                # vector entry — discovered via testing: deleting the
                # older version reported vectors_removed=0 because its
                # vector had already been clobbered by the newer one at
                # upload time. Including the full domain/module/
                # knowledge_name/version path keeps each version's
                # chunks distinct even when their content is identical.
                chunk_id = "_".join([
                    _id_part(domain),
                    _id_part(module),
                    _id_part(knowledge_name),
                    _id_part(version),
                    file_info["sha256"],
                    str(index),
                ])

                batch_items.append({
                    "doc_id": chunk_id,
                    "text": chunk,
                    "embedding": embedding,
                    "metadata": {
                        "domain": domain,
                        "module": module,
                        "knowledge_name": knowledge_name,
                        "version": version,

                        "file_name": file_info["file_name"],
                        "file_type": file_info["extension"],

                        "platform": analysis.get("platform", ""),
                        "category": analysis.get("category", ""),
                        "business_process": analysis.get("business_process", ""),
                        "document_type": analysis.get("document_type", ""),

                        "summary": analysis.get("summary", ""),

                        "tags": ",".join(
                            analysis.get("tags", [])
                        ),

                        "confidence": analysis.get("confidence", 0),

                        "chunk_number": index,
                        "total_chunks": len(chunks),
                    },
                })

            try:
                vectors_saved = self.vector_store.save_documents_batch(
                    batch_items
                )
            except Exception:
                rollback_persisted_upload()
                raise

# Everything after this point (the "return { ... }" block) stays
# exactly the same — vectors_saved and len(chunks) are still set,
# just computed more efficiently.

        return {
            "success": True,

            "domain": domain,
            "module": module,
            "knowledge_name": knowledge_name,
            "version": version,

            # AI Analysis
            "platform": analysis.get("platform", ""),
            "category": analysis.get("category", ""),
            "business_process": analysis.get("business_process", ""),
            "document_type": analysis.get("document_type", ""),
            "summary": analysis.get("summary", ""),
            "tags": analysis.get("tags", []),
            "confidence": analysis.get("confidence", 0),

            # Repository/File Information
            "repository_path": file_info.get("repository_path", ""),
            "file_name": file_info.get("file_name", ""),
            "file_type": file_info.get("extension", ""),

            # Upload Statistics
            "total_chunks": len(chunks),
            "vectors_saved": vectors_saved,

            # Existing Objects (keep these for compatibility)
            "file_info": file_info,
            "analysis": analysis,
            "metadata_status": metadata_status
        }

    # --------------------------------------------------
    # Backward Compatibility
    # --------------------------------------------------

    def upload(
        self,
        source_file,
        domain,
        module,
        knowledge_name,
        version="1.0",
        document_type=""
    ):

        return self.upload_file(
            source_file=source_file,
            domain=domain,
            module=module,
            knowledge_name=knowledge_name,
            version=version,
            document_type=document_type
        )

    # --------------------------------------------------
    # Upload Folder
    # --------------------------------------------------

    def upload_folder(

        self,

        folder,

        domain,

        module,

        knowledge_name,

        version="v1.0"

    ):

        folder = Path(folder).resolve()

        if not folder.exists():

            raise FileNotFoundError(folder)

        if not folder.is_dir():

            raise NotADirectoryError(folder)

        supported_extensions = {

            ".pdf",

            ".doc",

            ".docx",

            ".txt",

            ".xlsx",

            ".xls",

            ".csv",

            ".png",

            ".jpg",

            ".jpeg"

        }

        results = []

        total = 0

        success = 0

        failed = 0

        for file in folder.rglob("*"):

            if not file.is_file():

                continue

            if file.suffix.lower() not in supported_extensions:

                continue

            total += 1

            try:

                result = self.upload_file(

                    source_file=str(file),

                    domain=domain,

                    module=module,

                    knowledge_name=knowledge_name,

                    version=version

                )

                results.append(result)

                success += 1

            except Exception as ex:

                results.append({

                    "success": False,

                    "file": str(file),

                    "error": str(ex)

                })

                failed += 1

        return {

            "success": failed == 0,

            "total_files": total,

            "uploaded": success,

            "failed": failed,

            "results": results

        }
    
    # --------------------------------------------------
    # AI Smart Upload
    # --------------------------------------------------

    def smart_upload(

        self,

        source_file

    ):

        source_file = Path(source_file).resolve()

        analysis = self.smart_uploader.analyze(

        str(source_file)

    )

        return analysis

    # --------------------------------------------------
    # Delete Knowledge
    # --------------------------------------------------

    def delete_knowledge(
        self,
        domain,
        module,
        knowledge_name
    ):

        data = self.vector_store.get_all()

        if not data:
            return

        ids = data.get("ids", [])
        metadatas = data.get("metadatas", [])

        for doc_id, metadata in zip(ids, metadatas):

            if (
                metadata.get("domain") == domain
                and metadata.get("module") == module
                and metadata.get("knowledge_name") == knowledge_name
            ):

                self.vector_store.delete(doc_id)
